package com.signify.quotegenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuoteGeneratorApplicationTest {

    @Test
    void contextLoads() {
    }

}