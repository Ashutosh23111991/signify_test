insert into Quote values (1,'Nelson Mandela','The greatest glory in living lies not in never falling but in rising every time we fall.');
insert into Quote values (2,'Walt Disney','The way to get started is to quit talking and begin doing');
insert into Quote values (3,'John Lennon','Life is what happens when you''re busy making other plans');
insert into Quote values (4,'Anais Nin','We write to taste life twice, in the moment and in retrospect.');
insert into Quote values (5,'Saul Bellow','You never have to change anything you got up in the middle of the night to write.');
insert into Quote values (6,'Henry David Thoreau','How vain it is to sit down to write when you have not stood up to live.');
insert into Quote values (7,'Margaret Atwood','A word after a word after a word is power.');
insert into Quote values (8,'Paulo Coelho','Tears are words that need to be written.');
insert into Quote values (9,'','Tears are words that need to be written.');
insert into Quote values (10,'      ','Tears are words that need to be written.');
insert into Quote values (11,'   ','Tears are words that need to be written.');

